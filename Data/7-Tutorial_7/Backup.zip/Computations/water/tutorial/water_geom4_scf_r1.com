%chk=water_geom4_scf_r1.chk
#p nosymm scf=(maxconventionalcycles=200,xqc) UPBEPBE STO-3G

Title Card

0 1
O  0.015000  -0.020000  0.010000
H  0.950000  0.015000  0.040000
H  -0.260000  0.910000  -0.020000

