%chk=water_geom3_scf_r1.chk
#p nosymm scf=(maxconventionalcycles=200,xqc) UPBEPBE STO-3G

Title Card

0 1
O  -0.020000  -0.010000  0.005000
H  0.972000  -0.015000  0.030000
H  -0.210000  0.950000  0.040000

