%chk=water_geom2_freq_r1.chk
#p nosymm scf=(maxconventionalcycles=200,xqc) UPBEPBE STO-3G freq(hpmodes) EmpiricalDispersion=GD3BJ

Title Card

0 1
O  -0.034508  -0.054380  -0.007519
H  0.997418  0.042976  0.021039
H  -0.240911  0.961403  -0.046520

