%chk=water_geom1_scf_r1.chk
#p nosymm scf=(maxconventionalcycles=200,xqc) B3LYP STO-3G

Title Card

0 1
O  0.000000  0.000000  0.000000
H  0.957200  0.000000  0.000000
H  -0.239000  0.927000  0.000000

