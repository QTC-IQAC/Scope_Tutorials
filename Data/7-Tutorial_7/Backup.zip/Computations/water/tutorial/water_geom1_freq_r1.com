%chk=water_geom1_freq_r1.chk
#p nosymm scf=(maxconventionalcycles=200,xqc) UPBEPBE STO-3G freq(hpmodes) EmpiricalDispersion=GD3BJ

Title Card

0 1
O  -0.043628  -0.056241  -0.000000
H  0.990836  0.018982  0.000000
H  -0.229008  0.964259  0.000000

