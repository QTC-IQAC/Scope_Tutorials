%chk=water_geom1_opt_r1.chk
#p nosymm scf=(maxconventionalcycles=200,xqc) UPBEPBE STO-3G opt=(RecalcFC=30,cartesian,skipdihedral,loose) EmpiricalDispersion=GD3BJ

Title Card

0 1
O  0.000000  0.000000  0.000000
H  0.957200  0.000000  0.000000
H  -0.239000  0.927000  0.000000

