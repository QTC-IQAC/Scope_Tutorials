%chk=water_geom4_freq_r1.chk
#p nosymm scf=(maxconventionalcycles=200,xqc) UPBEPBE STO-3G freq(hpmodes) EmpiricalDispersion=GD3BJ

Title Card

0 1
O  -0.036546  -0.072083  0.009476
H  0.993995  0.034441  0.041011
H  -0.252448  0.942641  -0.020486

