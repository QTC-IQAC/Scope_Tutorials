%chk=water_geom3_freq_r1.chk
#p nosymm scf=(maxconventionalcycles=200,xqc) UPBEPBE STO-3G freq(hpmodes) EmpiricalDispersion=GD3BJ

Title Card

0 1
O  -0.045846  -0.047967  0.002768
H  0.989740  -0.002454  0.030971
H  -0.201894  0.975421  0.041261

