%chk=water_geom2_scf_r1.chk
#p nosymm scf=(maxconventionalcycles=200,xqc) UPBEPBE STO-3G

Title Card

0 1
O  0.012000  0.005000  -0.008000
H  0.950000  0.030000  0.020000
H  -0.240000  0.915000  -0.045000

