%chk=formaldehyde_geom1_freq_r1.chk
#p nosymm scf=(maxconventionalcycles=200,xqc) UPBEPBE STO-3G freq(hpmodes) EmpiricalDispersion=GD3BJ

Title Card

0 1
C  0.000000  -0.000000  -0.000693
O  -0.000000  0.000000  1.257502
H  -0.000000  0.945728  -0.628404
H  -0.000000  -0.945728  -0.628404

