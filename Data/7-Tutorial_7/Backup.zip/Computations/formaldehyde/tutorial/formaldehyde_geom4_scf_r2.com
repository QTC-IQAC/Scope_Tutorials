%chk=formaldehyde_geom4_scf_r2.chk
#p nosymm scf=(maxconventionalcycles=200,xqc) UPBEPBE STO-3G

Title Card

0 1
C  0.005000  0.005000  -0.015000
O  -0.010000  0.000000  1.210000
H  0.010000  0.955000  -0.610000
H  -0.020000  -0.945000  -0.590000

