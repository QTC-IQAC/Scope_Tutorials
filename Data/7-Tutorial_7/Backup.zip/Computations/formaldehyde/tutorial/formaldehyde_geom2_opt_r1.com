%chk=formaldehyde_geom2_opt_r1.chk
#p nosymm scf=(maxconventionalcycles=200,xqc) UPBEPBE STO-3G opt=(RecalcFC=30,cartesian,skipdihedral,loose) EmpiricalDispersion=GD3BJ

Title Card

0 1
C  0.010000  -0.015000  -0.010000
O  0.000000  0.030000  1.220000
H  0.020000  0.950000  -0.630000
H  -0.010000  -0.940000  -0.590000

