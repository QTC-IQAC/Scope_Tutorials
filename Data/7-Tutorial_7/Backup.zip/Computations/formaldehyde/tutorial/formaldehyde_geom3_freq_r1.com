%chk=formaldehyde_geom3_freq_r1.chk
#p nosymm scf=(maxconventionalcycles=200,xqc) UPBEPBE STO-3G freq(hpmodes) EmpiricalDispersion=GD3BJ

Title Card

0 1
C  -0.002159  -0.002778  -0.000056
O  0.005887  0.008141  1.257470
H  -0.024300  0.937389  -0.635716
H  0.010572  -0.952752  -0.621698

