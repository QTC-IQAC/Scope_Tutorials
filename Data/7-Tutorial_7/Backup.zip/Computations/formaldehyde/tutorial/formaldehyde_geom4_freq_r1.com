%chk=formaldehyde_geom4_freq_r1.chk
#p nosymm scf=(maxconventionalcycles=200,xqc) UPBEPBE STO-3G freq(hpmodes) EmpiricalDispersion=GD3BJ

Title Card

0 1
C  -0.003782  0.003667  -0.002156
O  -0.007109  0.007777  1.256121
H  0.012857  0.947360  -0.632311
H  -0.016966  -0.943804  -0.626654

