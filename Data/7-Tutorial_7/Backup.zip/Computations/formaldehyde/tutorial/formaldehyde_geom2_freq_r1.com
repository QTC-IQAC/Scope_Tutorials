%chk=formaldehyde_geom2_freq_r1.chk
#p nosymm scf=(maxconventionalcycles=200,xqc) UPBEPBE STO-3G freq(hpmodes) EmpiricalDispersion=GD3BJ

Title Card

0 1
C  0.004883  0.006165  -0.003494
O  0.001656  0.027438  1.254992
H  0.021710  0.940919  -0.646908
H  -0.008249  -0.949523  -0.614589

