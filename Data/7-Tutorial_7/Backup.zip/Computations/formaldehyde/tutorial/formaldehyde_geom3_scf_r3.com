%chk=formaldehyde_geom3_scf_r3.chk
#p nosymm scf=(maxconventionalcycles=200,xqc) UPBEPBE STO-3G

Title Card

0 1
C  -0.015000  0.010000  0.020000
O  0.010000  -0.010000  1.180000
H  -0.020000  0.940000  -0.620000
H  0.015000  -0.950000  -0.580000

