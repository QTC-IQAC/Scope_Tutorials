%chk=formaldehyde_geom1_scf_r1.chk
#p nosymm scf=(maxconventionalcycles=200,xqc) UPBEPBE STO-3G

Title Card

0 1
C  0.000000  0.000000  0.000000
O  0.000000  0.000000  1.200000
H  0.000000  0.943000  -0.600000
H  0.000000  -0.943000  -0.600000

